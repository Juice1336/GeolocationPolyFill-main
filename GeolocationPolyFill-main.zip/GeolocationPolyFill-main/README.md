# GeolocationPolyFill

Currently using the window.navigator.geolocation, to get latitude and longitude returns an error on the dart2js compiler.

This library solves this issue and enables smooth sailing

Thank Jesus